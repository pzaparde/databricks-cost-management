# Cost Management Accelerator - Data Contract

## 1. Inputs

### 1.1 Databricks usage (automatic)
| Source | Purpose |
| --- | --- |
| `system.billing.usage` | All DBU usage records (incl. RESTATEMENT / RETRACTION record types) |
| `system.billing.account_prices` | Negotiated price per SKU (preferred; optional - list prices are used if not available) |
| `system.billing.list_prices` | Fallback price per SKU when no account price exists |
| `system.access.workspaces_latest` | Workspace names (seeds `config_workspace_env`) |

### 1.2 Cloud cost files (manual upload)
Landing volume: `/Volumes/<catalog>/<schema>/<landing_volume>/<provider>/<source_folder>/*.csv`
Each `<provider>/<source_folder>` must be registered in `config_cloud_source`.

**Adapter `aws_cost_explorer_csv`** - AWS Cost Explorer export, *Group by: Service*, Daily or Monthly.
* Header row: `"Service", "<Service A>($)", ..., "Total costs($)"`
* Row 2: `"Service total"` (summary - not data)
* Rows 3+: one row per date (`yyyy-MM-dd`); blank = 0
* Granularity inferred: dates all on day 1 and >1 month span -> MONTHLY, else DAILY

**Adapter `generic_template_csv`** - any cloud / any tool. See `config/cloud_cost_template.csv`.
| Column | Type | Rule |
| --- | --- | --- |
| cost_date | date | DAILY = the day; MONTHLY = first day of month |
| granularity | string | DAILY or MONTHLY |
| provider | string | aws / azure / gcp / other |
| cloud_account_id | string | optional |
| environment | string | must match `config_workspace_env.environment` values, else UNASSIGNED |
| service_name | string | free text, normalised (trimmed, `($)` suffix removed) |
| cost | decimal | >= 0 (credits as negative allowed) |
| currency | string | ISO code |
| allocation_basis | string | TAGGED_DATABRICKS / ACCOUNT_TOTAL / ESTIMATED |

## 2. Processing rules (cloud cost)
1. **Lineage**: every row keeps `source_file`, `file_modification_time`, `ingested_at`.
2. **Summary rows removed**: `Service total` row and `Total costs($)` column are not data.
3. **Control total**: per file and date, sum(services) must equal `Total costs($)` within `control_total_tolerance_pct`; otherwise the whole file is quarantined with a reason.
4. **Latest file wins**: for the same (provider, source_folder, cost_date, granularity) the newest file replaces older ones - re-uploads never double count.
5. **No mixed granularity**: if a month has DAILY rows, its MONTHLY rows are ignored for that month; monthly views are derived from daily where possible.
6. **Service scope**: only `services_in_scope` from `config_cloud_source` (or ALL) reach gold; everything is kept in bronze.
7. **Quarantine**: unparseable / unregistered folders / failed control totals go to `cloud_cost_quarantine`; the pipeline does not fail.

## 3. Processing rules (Databricks)
1. Incremental by `usage_date` with `lookback_days` re-read; upsert on `record_id`.
2. Restatements / retractions honoured so totals match `system.billing.usage`.
3. Price per record: account price valid at `usage_end_time`; else list price x (1 - `list_price_discount_pct`/100); then x (1 - `additional_discount_pct`/100). `price_source` column records ACCOUNT / LIST.
4. Environment from `config_workspace_env`; tag attributes from `config_tag_mapping`; workload name derived per billing product.
5. Money stored as DECIMAL(38,10) in silver, DECIMAL(18,4) in gold.

## 4. Outputs (all in `<catalog>.<schema>`)
| Object | Grain |
| --- | --- |
| `bronze_billing_usage` | 1 row per `record_id` (system table copy, beyond system-table retention) |
| `silver_billing_usage` | 1 row per `record_id`, priced and enriched |
| `gold_dbx_cost_daily` | date x workspace x environment x sku x billing product x workload x product/sub_product x photon x serverless |
| `gold_dbx_cost_monthly` | same at month grain |
| `bronze_cloud_cost_raw` | 1 row per file line (raw) |
| `silver_cloud_cost` | standard long format, deduplicated (latest file wins) |
| `gold_cloud_cost_monthly` | month x provider x environment x service |
| `gold_total_cost_monthly` | Databricks + cloud, month x environment x cost_source |
| `cloud_cost_quarantine` | rejected files with reason |
| `dq_reconciliation` | per run: silver/gold totals vs system tables |

## 5. Identity attribution

Databricks cost is attributed to the identity that ran each workload:
1. **Primary**: `identity_metadata.run_as` from `system.billing.usage`.
2. **Fallback**: `owned_by`, then `created_by`.
3. **Classification**: User (email), Service principal (application UUID), Shared compute (no identity), or Unknown (seen in billing but not in this workspace's SCIM directory - typically identities from other workspaces in `workspace_filter`).
4. **Name resolution**: `config_identity` is refreshed from the workspace SCIM API on every setup run. Dashboard label = `manual_name` > `display_name` > raw ID > `(shared / not attributable)`.
5. **First install**: billing-only (Unknown) identities are added from the second setup run onwards, because `bronze_billing_usage` does not exist until the pipeline has run once.
6. **Unknown identities**: resolve via account-level SCIM access or `UPDATE config_identity SET manual_name = '...' WHERE identity_id = '...'` (never overwritten by refreshes).
7. Shown on the **Products & Workloads** dashboard page (current month + previous 2 months).

### `config_identity` table
| Column | Type | Description |
| --- | --- | --- |
| `identity_id` | STRING | PK — email or application UUID |
| `identity_type` | STRING | `User`, `Service principal`, or `Unknown` |
| `display_name` | STRING | Name from SCIM |
| `manual_name` | STRING | User-editable override (takes priority in dashboard) |
| `active` | BOOLEAN | SCIM active flag (NULL for Unknown) |
| `last_refreshed` | TIMESTAMP | Last setup refresh of this row |

## 6. Budget

* Default annual budget: **2,000,000 USD** (Databricks + cloud, current calendar year).
* Dashboard viewers adjust via the **"Annual Budget (USD)"** input on the *Data Quality & Budget* page (parameter `annual_budget_usd`, default `2000000`).
* To change the org-wide default, edit the parameter default in the dashboard and redeploy.
* **Budget vs Actual table** (current year, month by month): for each month, a `config_budget` row with `environment IS NULL`, `product IS NULL` and `cost_scope` = `TOTAL` (or NULL) is used; if there is none, the budget is `annual_budget_usd / 12`. Column `budget_source` shows which (`config_budget` or `annual / 12`). An empty `config_budget` is valid.
* `config_budget` columns: `budget_month` (first day of month), `environment` (NULL = all), `product` (NULL = all), `cost_scope` (`DATABRICKS|CLOUD|TOTAL`), `budget_amount`, `currency`, `updated_at`. Rows scoped to a specific environment/product are stored for future use but not yet shown on the dashboard.

## 7. Known attribution limits (AWS)
* Classic compute EC2/EBS carry Databricks default tags (`Vendor=Databricks`, `ClusterId`, `JobId`...), but tags must be **activated as cost allocation tags** in AWS Billing to be filterable in Cost Explorer.
* `EC2-Other` (NAT gateway, data transfer, EBS snapshots, Elastic IPs) and **S3** are mostly NOT tagged by Databricks -> reported as `ACCOUNT_TOTAL` unless the customer tags buckets/network resources.
* Serverless compute runs in the Databricks account: its infrastructure cost is already inside the DBU price and never appears in the AWS bill.
