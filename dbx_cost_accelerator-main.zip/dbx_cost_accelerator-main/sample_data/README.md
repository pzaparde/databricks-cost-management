# Sample Data

This folder mirrors the layout of the landing volume (`/Volumes/<catalog>/<schema>/cloud_cost_landing/`).
Files here are **anonymized dummy data for demo and testing only** — cost values have been randomly scaled and do not represent real spend.

## Folder structure

```
sample_data/
└── cloud_cost_landing/
    ├── aws/
    │   ├── prod/   -> aws_cost_explorer_sample_prod.csv
    │   └── test/   -> aws_cost_explorer_sample_test.csv
    └── generic/
        └── manual/ -> generic_template_sample.csv
```

## Using the samples

1. Deploy the bundle and run the setup task so the landing volume exists.
2. Copy the sample files into the volume, preserving the `<provider>/<source_folder>/` structure:
   ```bash
   # Example — copy the AWS prod sample into the landing volume
   databricks fs cp sample_data/cloud_cost_landing/aws/prod/aws_cost_explorer_sample_prod.csv \
     /Volumes/<catalog>/<schema>/cloud_cost_landing/aws/prod/
   ```
3. Run the pipeline. It will ingest and process the files like real cloud cost data.

## Where REAL cloud cost files go

Upload actual cloud cost exports to:

```
/Volumes/<catalog>/<schema>/cloud_cost_landing/<provider>/<source_folder>/
```

Each `<provider>/<source_folder>` combination must match a row in `config_cloud_source` (seeded on first run from `config/cloud_sources_seed.csv`). Examples:

| Provider | Source folder | Adapter | Description |
| --- | --- | --- | --- |
| `aws` | `prod` | `aws_cost_explorer_csv` | AWS Cost Explorer export for the prod account |
| `aws` | `test` | `aws_cost_explorer_csv` | AWS Cost Explorer export for the test account |
| `generic` | `manual` | `generic_template_csv` | Any provider, using the template format (`config/cloud_cost_template.csv`) |

File names within the folder do not matter — the pipeline reads all `.csv` files and deduplicates by (provider, source_folder, cost_date, granularity), keeping the latest file.
