-- =====================================================================
-- Cost Management Accelerator - 00_setup.sql
-- Idempotent bootstrap: safe to run on every deployment / job run.
-- Executed by src/setup/run_setup (job task 'setup') with named parameters:
--   :catalog, :schema, :landing_volume
-- PREREQUISITE: the catalog must exist. run_setup creates the schema first if it
-- is missing; this script never creates, alters or drops a catalog or schema.
-- Creates ONLY user-editable objects (config tables + landing volume).
-- All bronze/silver/gold tables are owned by the Lakeflow pipeline.
-- =====================================================================

USE CATALOG IDENTIFIER(:catalog);

-- The schema is used as-is (run_setup has already created it if it was missing).
USE SCHEMA IDENTIFIER(:schema);

-- ---------------------------------------------------------------------
-- 1. Landing volume for manual cloud cost files
--    Folder convention: /<provider>/<source_folder>/<file>.csv
--    e.g. /aws/prod/aws-prod-2026-09.csv
-- ---------------------------------------------------------------------
CREATE VOLUME IF NOT EXISTS IDENTIFIER(:landing_volume)
  COMMENT 'Drop zone for cloud cost exports (AWS Cost Explorer CSV or generic template CSV)';

-- ---------------------------------------------------------------------
-- 2. Workspace -> environment / business unit mapping
--    Auto-seeded from system.access.workspaces_latest; edit freely.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS config_workspace_env (
  workspace_id    STRING  NOT NULL COMMENT 'Databricks workspace ID',
  workspace_name  STRING           COMMENT 'Workspace name (from system.access.workspaces_latest)',
  environment     STRING           COMMENT 'PROD / DEV / TEST / QA / UAT / CERT / UNASSIGNED',
  business_unit   STRING           COMMENT 'Optional owning business unit',
  include_flag    BOOLEAN          COMMENT 'Include this workspace in cost reporting',
  updated_at      TIMESTAMP,
  updated_by      STRING
) COMMENT 'Editable mapping of workspaces to environments. Seeded automatically; manual edits are never overwritten.';

MERGE INTO config_workspace_env t
USING (
  SELECT
    workspace_id,
    workspace_name,
    CASE
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(prod|prd|production)([-_ ]|$)' THEN 'PROD'
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(dev|development)([-_ ]|$)'     THEN 'DEV'
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(test|tst)([-_ ]|$)'            THEN 'TEST'
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(qa)([-_ ]|$)'                  THEN 'QA'
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(uat|stage|staging|stg)([-_ ]|$)' THEN 'UAT'
      WHEN lower(workspace_name) RLIKE '(^|[-_ ])(cert)([-_ ]|$)'                THEN 'CERT'
      ELSE 'UNASSIGNED'
    END AS environment
  FROM system.access.workspaces_latest
  WHERE status = 'RUNNING'
) s
ON t.workspace_id = s.workspace_id
WHEN MATCHED AND t.workspace_name IS DISTINCT FROM s.workspace_name THEN
  UPDATE SET t.workspace_name = s.workspace_name, t.updated_at = current_timestamp(), t.updated_by = 'setup'
WHEN NOT MATCHED THEN
  INSERT (workspace_id, workspace_name, environment, business_unit, include_flag, updated_at, updated_by)
  VALUES (s.workspace_id, s.workspace_name, s.environment, NULL, TRUE, current_timestamp(), 'setup');

-- ---------------------------------------------------------------------
-- 3. Tag mapping: company tag keys -> standard reporting attributes
--    Lowest priority number wins when several keys map to one attribute.
--    Defaults are seeded ONLY when the table is empty, so rows a customer
--    deletes or changes are never re-added.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS config_tag_mapping (
  standard_attribute STRING NOT NULL COMMENT 'product | sub_product | cost_center | team | owner | project',
  source_tag_key     STRING NOT NULL COMMENT 'Tag key as it appears in system.billing.usage.custom_tags',
  priority           INT             COMMENT '1 = preferred key',
  updated_at         TIMESTAMP
) COMMENT 'Maps each company''s tag keys to standard attributes used by the dashboard.';

MERGE INTO config_tag_mapping t
USING (
  SELECT * FROM VALUES
    ('product',     'product',     1),
    ('sub_product', 'subproduct',  1),
    ('sub_product', 'sub_product', 2),
    ('cost_center', 'cost_center', 1),
    ('cost_center', 'CostCenter',  2),
    ('team',        'team',        1),
    ('owner',       'owner',       1),
    ('project',     'project',     1)
  AS v(standard_attribute, source_tag_key, priority)
  WHERE NOT EXISTS (SELECT 1 FROM config_tag_mapping)
) s
ON t.standard_attribute = s.standard_attribute AND t.source_tag_key = s.source_tag_key
WHEN NOT MATCHED THEN
  INSERT (standard_attribute, source_tag_key, priority, updated_at)
  VALUES (s.standard_attribute, s.source_tag_key, s.priority, current_timestamp());

-- ---------------------------------------------------------------------
-- 4. Cloud cost sources: one row per landing sub-folder
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS config_cloud_source (
  provider          STRING NOT NULL COMMENT 'aws | azure | gcp | other',
  source_folder     STRING NOT NULL COMMENT 'Sub-folder under /<provider>/ in the landing volume',
  adapter           STRING NOT NULL COMMENT 'aws_cost_explorer_csv | generic_template_csv',
  environment       STRING          COMMENT 'Environment the costs belong to (matches config_workspace_env.environment)',
  cloud_account_id  STRING          COMMENT 'AWS account / Azure subscription / GCP project',
  allocation_basis  STRING          COMMENT 'TAGGED_DATABRICKS | ACCOUNT_TOTAL | ESTIMATED',
  services_in_scope STRING          COMMENT 'Comma-separated services to keep (e.g. EC2-Instances,EC2-Other,S3) or ALL',
  currency          STRING,
  active            BOOLEAN,
  updated_at        TIMESTAMP
) COMMENT 'Registers each landing folder and how to interpret its files.';

-- ---------------------------------------------------------------------
-- 5. Optional monthly budgets (used for budget vs actual + alerts)
-- ---------------------------------------------------------------------
-- ---------------------------------------------------------------------
-- 6. Identity lookup: resolves user emails and service principal IDs
--    to human-readable names. Auto-refreshed from the SCIM API on each
--    setup run; manual_name column is never overwritten.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS config_identity (
  identity_id     STRING  NOT NULL COMMENT 'User email or service principal application ID',
  identity_type   STRING           COMMENT 'User | Service principal | Unknown',
  display_name    STRING           COMMENT 'Name from the workspace identity provider (SCIM)',
  manual_name     STRING           COMMENT 'Manual override - takes precedence over display_name',
  active          BOOLEAN          COMMENT 'Currently active in the workspace',
  last_refreshed  TIMESTAMP
) COMMENT 'Maps billing identities to human-readable names. Auto-refreshed; edit manual_name for overrides.';

-- ---------------------------------------------------------------------
-- 7. Optional monthly budgets (used for budget vs actual + alerts)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS config_budget (
  budget_month  DATE   NOT NULL COMMENT 'First day of month',
  environment   STRING          COMMENT 'NULL = all environments',
  product       STRING          COMMENT 'NULL = all products',
  cost_scope    STRING          COMMENT 'DATABRICKS | CLOUD | TOTAL',
  budget_amount DECIMAL(18,2),
  currency      STRING,
  updated_at    TIMESTAMP
) COMMENT 'Optional budgets; leave empty if not used.';
