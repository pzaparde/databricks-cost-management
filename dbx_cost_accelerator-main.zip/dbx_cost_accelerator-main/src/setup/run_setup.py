# Databricks notebook source
# DBTITLE 1,Parameters
# Cost Management Accelerator - setup task
# Runs src/setup/00_setup.sql with named parameters, then seeds config_cloud_source
# from config/cloud_sources_seed.csv ONLY when that table is empty.
# Idempotent: safe to run before every pipeline refresh.

dbutils.widgets.text("catalog", "")
dbutils.widgets.text("schema", "")
dbutils.widgets.text("landing_volume", "cloud_cost_landing")
dbutils.widgets.dropdown("load_sample_data", "false", ["false", "true"])

# Copies sample_data/cloud_cost_landing/* into the landing volume (demo / testing only).
LOAD_SAMPLE_DATA = dbutils.widgets.get("load_sample_data").strip().lower() == "true"

params = {
    "catalog": dbutils.widgets.get("catalog").strip(),
    "schema": dbutils.widgets.get("schema").strip(),
    "landing_volume": dbutils.widgets.get("landing_volume").strip(),
}
missing = [k for k, v in params.items() if not v]
if missing:
    raise ValueError(f"Missing required parameters: {missing}")

# The catalog must exist. The schema is created only if it does not exist yet
# (an existing schema is never altered or dropped).
if not spark.catalog.databaseExists(f"{params['catalog']}.{params['schema']}"):
    try:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{params['catalog']}`.`{params['schema']}` "
                  "COMMENT 'Cost Management Accelerator'")
        print(f"Created schema {params['catalog']}.{params['schema']}")
    except Exception as e:
        raise RuntimeError(
            f"Schema {params['catalog']}.{params['schema']} does not exist and could not be created "
            f"({str(e).splitlines()[0][:200]}). Ask an admin to GRANT USE CATALOG, CREATE SCHEMA "
            f"ON CATALOG {params['catalog']}, or to create the schema."
        )
print(params, "| load_sample_data =", LOAD_SAMPLE_DATA)

# COMMAND ----------

# DBTITLE 1,Preflight checks
# Preflight: fail fast with a clear message instead of a cryptic error deep in the pipeline.
# REQUIRED system tables must be readable by the run-as identity.
# OPTIONAL tables only produce a warning (the pipeline falls back automatically).
REQUIRED = ["system.billing.usage", "system.billing.list_prices", "system.access.workspaces_latest"]
OPTIONAL = {"system.billing.account_prices": "negotiated prices unavailable - list prices will be used"}

problems = []
for t in REQUIRED:
    try:
        spark.sql(f"SELECT 1 FROM {t} LIMIT 1").collect()
        print(f"OK       {t}")
    except Exception as e:
        problems.append(t)
        print(f"MISSING  {t}: {str(e).splitlines()[0][:160]}")

for t, note in OPTIONAL.items():
    try:
        spark.sql(f"SELECT 1 FROM {t} LIMIT 1").collect()
        print(f"OK       {t}")
    except Exception:
        print(f"WARNING  {t}: {note}")

if problems:
    raise PermissionError(
        f"Cannot read {problems}. Ask an account/metastore admin to enable the system.billing and "
        "system.access schemas and GRANT USE SCHEMA + SELECT on them to the identity running this setup."
    )
print("Preflight passed.")

# COMMAND ----------

# DBTITLE 1,Run 00_setup.sql
import os
import re

_nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
SETUP_DIR = "/Workspace" + os.path.dirname(_nb_path) if not _nb_path.startswith("/Workspace") else os.path.dirname(_nb_path)
BUNDLE_ROOT = os.path.dirname(os.path.dirname(SETUP_DIR))

with open(os.path.join(SETUP_DIR, "00_setup.sql")) as f:
    sql_text = f.read()

# Strip full-line comments, then split on ';' at end of line
sql_no_comments = "\n".join(l for l in sql_text.splitlines() if not l.strip().startswith("--"))
statements = [s.strip() for s in re.split(r";\s*(?:\n|$)", sql_no_comments) if s.strip()]

for i, stmt in enumerate(statements, 1):
    first_line = stmt.splitlines()[0][:90]
    print(f"[{i}/{len(statements)}] {first_line}")
    spark.sql(stmt, args=params)

print(f"Executed {len(statements)} statements from 00_setup.sql")

# COMMAND ----------

# DBTITLE 1,Seed config_cloud_source if empty
import csv

cfg_table = f"`{params['catalog']}`.`{params['schema']}`.config_cloud_source"
seed_file = os.path.join(BUNDLE_ROOT, "config", "cloud_sources_seed.csv")

existing = spark.table(cfg_table).limit(1).count()
if existing:
    print(f"{cfg_table} already has rows - seed skipped (existing configuration is never overwritten).")
elif not os.path.exists(seed_file):
    print(f"No seed file at {seed_file} - register cloud sources manually.")
else:
    with open(seed_file) as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        spark.sql(
            f"""INSERT INTO {cfg_table}
                (provider, source_folder, adapter, environment, cloud_account_id, allocation_basis,
                 services_in_scope, currency, active, updated_at)
                VALUES (:provider, :source_folder, :adapter, nullif(:environment, ''), nullif(:cloud_account_id, ''),
                        nullif(:allocation_basis, ''), :services_in_scope, :currency,
                        lower(:active) = 'true', current_timestamp())""",
            args={
                **{k: (v or "").strip() for k, v in r.items()},
                # '|' is used in the CSV so the list survives CSV quoting; stored comma-separated
                "services_in_scope": (r.get("services_in_scope") or "ALL").strip().replace("|", ","),
            },
        )
    print(f"Seeded {len(rows)} rows into {cfg_table} from {seed_file}")

# COMMAND ----------

# DBTITLE 1,Load sample cloud cost data (optional)
# Demo / test only: copy the anonymized CSVs from sample_data/cloud_cost_landing/<provider>/<folder>/
# into the landing volume. Files already present (same name) are left untouched, so this is idempotent.
# Delete these files from the volume before loading real cloud cost exports.
import shutil

if not LOAD_SAMPLE_DATA:
    print("load_sample_data = false - skipped.")
else:
    src_root = os.path.join(BUNDLE_ROOT, "sample_data", "cloud_cost_landing")
    dst_root = f"/Volumes/{params['catalog']}/{params['schema']}/{params['landing_volume']}"
    if not os.path.isdir(src_root):
        print(f"No sample data folder at {src_root} - skipped.")
    else:
        copied, skipped = 0, 0
        for dirpath, _, files in os.walk(src_root):
            for fn in files:
                if not fn.lower().endswith(".csv"):
                    continue
                rel = os.path.relpath(os.path.join(dirpath, fn), src_root)
                dst = os.path.join(dst_root, rel)
                if os.path.exists(dst):
                    skipped += 1
                    continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(os.path.join(dirpath, fn), dst)
                copied += 1
                print(f"copied  {rel}")
        print(f"Sample data: {copied} copied, {skipped} already present -> {dst_root}")

# COMMAND ----------

# DBTITLE 1,Refresh config_identity from SCIM + billing
# ── Refresh config_identity ─────────────────────────────────────────
# 1) Pull every user and service principal visible in THIS workspace
#    via the Databricks SDK (SCIM API).
# 2) Add any identity seen in billing but NOT yet in the lookup
#    (other workspaces, deleted principals) with type 'Unknown'.
# 3) MERGE: update display_name + active, NEVER touch manual_name.
# ─────────────────────────────────────────────────────────────────────
from databricks.sdk import WorkspaceClient
from pyspark.sql import functions as F
from datetime import datetime

w = WorkspaceClient()
id_table = f"`{params['catalog']}`.`{params['schema']}`.config_identity"

# -- 1. Collect workspace users
identity_rows = []
for u in w.users.list(attributes="userName,displayName,name,active"):
    name_parts = []
    if u.name:
        if u.name.given_name: name_parts.append(u.name.given_name)
        if u.name.family_name: name_parts.append(u.name.family_name)
    display = " ".join(name_parts) if name_parts else (u.display_name or u.user_name)
    identity_rows.append({
        "identity_id": u.user_name,
        "identity_type": "User",
        "display_name": display,
        "active": u.active if u.active is not None else True,
    })

# -- 2. Collect service principals
for sp in w.service_principals.list(attributes="applicationId,displayName,active"):
    identity_rows.append({
        "identity_id": sp.application_id,
        "identity_type": "Service principal",
        "display_name": sp.display_name or sp.application_id,
        "active": sp.active if sp.active is not None else True,
    })

print(f"Workspace identities: {sum(1 for r in identity_rows if r['identity_type']=='User')} users, "
      f"{sum(1 for r in identity_rows if r['identity_type']=='Service principal')} service principals")

# -- 3. Add billing identities not yet known (other workspaces, deleted)
#    On a brand-new install the pipeline has not run yet, so bronze_billing_usage
#    does not exist. Skip this step; the next setup run will pick them up.
bronze_tbl = f"{params['catalog']}.{params['schema']}.bronze_billing_usage"
if not spark.catalog.tableExists(bronze_tbl):
    print(f"{bronze_tbl} not found (first install) - billing-only identities will be added on the next run.")
    billing_ids = []
else:
  billing_ids = (
    spark.table(bronze_tbl)
    .select(
        F.coalesce(
            F.col("identity_metadata.run_as"),
            F.col("identity_metadata.owned_by"),
            F.col("identity_metadata.created_by"),
        ).alias("identity_id")
    )
    .filter("identity_id IS NOT NULL")
    .distinct()
    .collect()
)
known = {r["identity_id"] for r in identity_rows}
for row in billing_ids:
    bid = row.identity_id
    if bid not in known:
        identity_rows.append({
            "identity_id": bid,
            "identity_type": "Unknown",
            "display_name": bid,  # raw ID as fallback
            "active": None,
        })

print(f"Total identities (incl. billing-only): {len(identity_rows)}")

# -- 4. MERGE into config_identity
from pyspark.sql.types import StructType, StructField, StringType, BooleanType
schema = StructType([
    StructField("identity_id", StringType()),
    StructField("identity_type", StringType()),
    StructField("display_name", StringType()),
    StructField("active", BooleanType()),
])
df_src = spark.createDataFrame(identity_rows, schema)
df_src.createOrReplaceTempView("_identity_src")

spark.sql(f"""
  MERGE INTO {id_table} t
  USING _identity_src s ON t.identity_id = s.identity_id
  WHEN MATCHED THEN UPDATE SET
    t.identity_type = s.identity_type,
    t.display_name  = s.display_name,
    t.active        = s.active,
    t.last_refreshed = current_timestamp()
  WHEN NOT MATCHED THEN INSERT
    (identity_id, identity_type, display_name, manual_name, active, last_refreshed)
    VALUES (s.identity_id, s.identity_type, s.display_name, NULL, s.active, current_timestamp())
""")

result = spark.table(id_table)
print(f"config_identity: {result.count()} rows")
result.groupBy("identity_type").count().show()

# COMMAND ----------

# DBTITLE 1,Summary
for t in ["config_workspace_env", "config_tag_mapping", "config_cloud_source", "config_budget", "config_identity"]:
    n = spark.table(f"`{params['catalog']}`.`{params['schema']}`.{t}").count()
    print(f"{t}: {n} rows")
