"""Bronze layer: Raw cloud cost files ingested via Auto Loader from the landing volume.
One row per file (whole-text) with file metadata persisted. Adapter-specific parsing in silver.
Landing path: /Volumes/<catalog>/<schema>/<landing_volume>/<provider>/<source_folder>/<file>
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.table(
    name="bronze_cloud_cost_raw",
    comment="Raw cloud cost files from the landing volume (whole file text) with file metadata.",
)
def bronze_cloud_cost_raw():
    catalog = spark.conf.get("catalog")
    schema_name = spark.conf.get("schema")
    landing_volume = spark.conf.get("landing_volume")
    landing_path = f"/Volumes/{catalog}/{schema_name}/{landing_volume}"

    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "text")
        .option("wholetext", "true")
        .option("pathGlobFilter", "*.csv")
        .load(landing_path)
        .select(
            F.col("value").alias("file_content"),
            F.col("_metadata.file_path").alias("source_file"),
            F.col("_metadata.file_name").alias("file_name"),
            F.col("_metadata.file_modification_time").alias("file_modification_time"),
            F.col("_metadata.file_size").alias("file_size"),
            F.current_timestamp().alias("ingested_at"),
            # provider / source_folder from the last 3 path segments: provider/folder/file
            F.regexp_extract(F.col("_metadata.file_path"), r"/([^/]+)/([^/]+)/[^/]+$", 1).alias("provider"),
            F.regexp_extract(F.col("_metadata.file_path"), r"/([^/]+)/([^/]+)/[^/]+$", 2).alias("source_folder"),
        )
    )
