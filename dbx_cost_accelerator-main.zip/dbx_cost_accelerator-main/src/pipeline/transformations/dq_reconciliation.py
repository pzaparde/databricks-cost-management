"""Data-quality reconciliation.
Compares pipeline bronze/silver/gold totals with system.billing.usage to detect drift.
One row per refresh.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, sum as _sum, abs as _abs


@dp.materialized_view(
    name="dq_reconciliation",
    comment="Per-refresh reconciliation of pipeline totals vs system tables.",
)
def dq_reconciliation():
    ws_filter = spark.conf.get("workspace_filter")
    history_start = spark.conf.get("history_start_date", "").strip() or "2025-01-01"

    system_usage = spark.read.table("system.billing.usage").filter(
        col("usage_date") >= lit(history_start)
    )
    if ws_filter.strip().upper() != "ALL":
        ws_ids = [w.strip() for w in ws_filter.split(",") if w.strip()]
        system_usage = system_usage.filter(col("workspace_id").isin(ws_ids))

    sys_agg = system_usage.agg(
        _sum("usage_quantity").alias("sys_quantity"),
        F.count("*").alias("sys_rows"),
    )

    bronze_agg = spark.read.table("bronze_billing_usage").agg(
        _sum("usage_quantity").alias("bronze_quantity"),
        F.count("*").alias("bronze_rows"),
    )

    silver_agg = spark.read.table("silver_billing_usage").agg(
        _sum("usage_quantity").alias("silver_quantity"),
        _sum("usage_cost").alias("silver_cost"),
        F.count("*").alias("silver_rows"),
    )

    gold_agg = spark.read.table("gold_dbx_cost_daily").agg(
        _sum("usage_quantity").alias("gold_quantity"),
        _sum("usage_cost").alias("gold_cost"),
        _sum("record_count").alias("gold_source_rows"),
    )

    recon = (
        sys_agg.crossJoin(bronze_agg)
        .crossJoin(silver_agg)
        .crossJoin(gold_agg)
        .withColumn("check_timestamp", F.current_timestamp())
        .withColumn("bronze_vs_system_row_diff", col("bronze_rows") - col("sys_rows"))
        .withColumn(
            "bronze_vs_system_qty_pct",
            F.when(
                col("sys_quantity") != 0,
                _abs(col("bronze_quantity") - col("sys_quantity")) / col("sys_quantity") * 100,
            ).otherwise(lit(0)),
        )
        .withColumn("silver_vs_bronze_row_diff", col("silver_rows") - col("bronze_rows"))
        .withColumn(
            "gold_vs_silver_cost_pct",
            F.when(
                col("silver_cost") != 0,
                _abs(col("gold_cost") - col("silver_cost")) / col("silver_cost") * 100,
            ).otherwise(lit(0)),
        )
    )

    return recon.select(
        "check_timestamp",
        "sys_rows",
        "sys_quantity",
        "bronze_rows",
        "bronze_quantity",
        "bronze_vs_system_row_diff",
        "bronze_vs_system_qty_pct",
        "silver_rows",
        "silver_quantity",
        "silver_cost",
        "silver_vs_bronze_row_diff",
        "gold_source_rows",
        "gold_quantity",
        "gold_cost",
        "gold_vs_silver_cost_pct",
    )
