"""Silver layer: Cloud cost normalisation, control-total validation, quarantine, and dedup.
Reads whole-file text from bronze_cloud_cost_raw, parses per adapter, and produces the
standard long format. Latest file wins for the same (provider, source_folder, cost_date, granularity).

Adapters:
  aws_cost_explorer_csv  - AWS Cost Explorer wide export (Service header, Service total row, date rows)
  generic_template_csv   - config/cloud_cost_template.csv (9 columns, any provider)
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, when, coalesce
from pyspark.sql.window import Window


def _config_table():
    return f"{spark.conf.get('catalog')}.{spark.conf.get('schema')}.config_cloud_source"


# =====================================================================
# Helper: Parse AWS Cost Explorer wide CSV (whole-file content string)
# =====================================================================
@dp.temporary_view()
def _aws_parsed():
    """Unpivot AWS Cost Explorer CSV into long format."""
    bronze = spark.read.table("bronze_cloud_cost_raw")
    config = spark.read.table(_config_table()).filter(
        (col("active") == True) & (col("adapter") == "aws_cost_explorer_csv")
    )

    aws_files = bronze.join(
        config.select(
            col("provider").alias("cfg_prov"),
            col("source_folder").alias("cfg_folder"),
            col("environment").alias("cfg_env"),
            col("allocation_basis").alias("cfg_alloc"),
            col("services_in_scope").alias("cfg_scope"),
            col("currency").alias("cfg_currency"),
        ),
        (col("provider") == col("cfg_prov")) & (col("source_folder") == col("cfg_folder")),
        "inner",
    )

    lines = aws_files.select(
        "source_file", "file_modification_time", "ingested_at",
        "cfg_env", "cfg_alloc", "cfg_scope", "cfg_currency",
        "provider", "source_folder",
        F.posexplode(F.split(col("file_content"), "\n")).alias("line_num", "line_text"),
    ).filter(F.trim(F.regexp_replace(col("line_text"), r"\r", "")) != "")

    # header (line 0), summary 'Service total' (line 1), data (line 2+)
    header_lines = lines.filter(col("line_num") == 0).select(
        col("source_file").alias("h_file"),
        col("line_text").alias("header_text"),
    )
    data_lines = lines.filter(col("line_num") >= 2)

    with_header = data_lines.join(header_lines, col("source_file") == col("h_file"))
    with_header = with_header.withColumn(
        "header_cols", F.split(F.regexp_replace(F.trim(col("header_text")), r'["\r]', ""), ",")
    ).withColumn(
        "data_vals", F.split(F.regexp_replace(F.trim(col("line_text")), r'["\r]', ""), ",")
    )

    exploded = (
        with_header.withColumn("pairs", F.arrays_zip(col("header_cols"), col("data_vals")))
        .select(
            "source_file", "file_modification_time", "ingested_at",
            "cfg_env", "cfg_alloc", "cfg_scope", "cfg_currency",
            "provider", "source_folder",
            F.element_at(col("data_vals"), 1).alias("cost_date_str"),
            F.explode("pairs").alias("pair"),
        )
        .select(
            "*",
            col("pair.header_cols").alias("column_name"),
            col("pair.data_vals").alias("cost_str"),
        )
    )

    services = exploded.filter(
        (col("column_name") != "Service")
        & (col("column_name") != "Total costs($)")
        & col("column_name").isNotNull()
    )

    parsed = services.select(
        col("provider"),
        col("source_folder"),
        col("cfg_env").alias("environment"),
        F.to_date(col("cost_date_str"), "yyyy-MM-dd").alias("cost_date"),
        F.regexp_replace(col("column_name"), r"\(\$\)$", "").alias("service_name"),
        when((col("cost_str").isNull()) | (col("cost_str") == ""), lit(0))
        .otherwise(col("cost_str"))
        .cast("decimal(18,4)")
        .alias("cost"),
        col("cfg_currency").alias("currency"),
        col("cfg_alloc").alias("allocation_basis"),
        col("source_file"),
        col("file_modification_time"),
        col("ingested_at"),
        lit("aws_cost_explorer_csv").alias("adapter"),
    )

    # Granularity: all dates day-1 across >1 month -> MONTHLY, else DAILY
    w_file = Window.partitionBy("source_file")
    parsed = (
        parsed.withColumn("_day", F.dayofmonth("cost_date"))
        .withColumn("_distinct_months", F.size(F.collect_set(F.date_trunc("month", "cost_date")).over(w_file)))
        .withColumn("_all_day_one", F.min("_day").over(w_file) == F.max("_day").over(w_file))
        .withColumn(
            "granularity",
            when((col("_all_day_one")) & (col("_day") == 1) & (col("_distinct_months") > 1), lit("MONTHLY"))
            .otherwise(lit("DAILY")),
        )
        .drop("_day", "_distinct_months", "_all_day_one")
    )

    return parsed


# =====================================================================
# Helper: Parse generic template CSV (whole-file content string)
# Columns: cost_date, granularity, provider, cloud_account_id, environment,
#          service_name, cost, currency, allocation_basis
# =====================================================================
@dp.temporary_view()
def _generic_parsed():
    bronze = spark.read.table("bronze_cloud_cost_raw")
    config = spark.read.table(_config_table()).filter(
        (col("active") == True) & (col("adapter") == "generic_template_csv")
    )

    generic_files = bronze.join(
        config.select(
            col("provider").alias("cfg_prov"),
            col("source_folder").alias("cfg_folder"),
            col("currency").alias("cfg_currency"),
            col("environment").alias("cfg_env"),
            col("allocation_basis").alias("cfg_alloc"),
        ),
        (col("provider") == col("cfg_prov")) & (col("source_folder") == col("cfg_folder")),
        "inner",
    )

    lines = generic_files.select(
        "source_file", "file_modification_time", "ingested_at",
        "provider", "source_folder", "cfg_currency", "cfg_env", "cfg_alloc",
        F.posexplode(F.split(col("file_content"), "\n")).alias("line_num", "line_text"),
    ).filter((col("line_num") > 0) & (F.trim(F.regexp_replace(col("line_text"), r"\r", "")) != ""))

    cols = F.split(F.regexp_replace(F.trim(col("line_text")), r'["\r]', ""), ",")

    def _field(i):
        v = F.trim(F.element_at(cols, i))
        return when(v == "", lit(None)).otherwise(v)

    parsed = lines.select(
        col("provider"),
        col("source_folder"),
        coalesce(_field(5), col("cfg_env")).alias("environment"),
        F.to_date(_field(1), "yyyy-MM-dd").alias("cost_date"),
        F.upper(coalesce(_field(2), lit("DAILY"))).alias("granularity"),
        _field(6).alias("service_name"),
        _field(7).cast("decimal(18,4)").alias("cost"),
        coalesce(_field(8), col("cfg_currency")).alias("currency"),
        coalesce(_field(9), col("cfg_alloc")).alias("allocation_basis"),
        col("source_file"),
        col("file_modification_time"),
        col("ingested_at"),
        lit("generic_template_csv").alias("adapter"),
    )

    return parsed


# =====================================================================
# Control-total validation (AWS only - generic template has no totals column)
# =====================================================================
@dp.temporary_view()
def _control_totals():
    """For each AWS file x date, compare sum-of-services vs Total costs($)."""
    tolerance_pct = float(spark.conf.get("control_total_tolerance_pct"))

    bronze = spark.read.table("bronze_cloud_cost_raw")
    config = spark.read.table(_config_table()).filter(
        (col("active") == True) & (col("adapter") == "aws_cost_explorer_csv")
    )

    aws_files = bronze.join(
        config.select(col("provider").alias("cfg_prov"), col("source_folder").alias("cfg_folder")),
        (col("provider") == col("cfg_prov")) & (col("source_folder") == col("cfg_folder")),
        "inner",
    )

    lines = aws_files.select(
        col("source_file"),
        F.posexplode(F.split(col("file_content"), "\n")).alias("line_num", "line_text"),
    ).filter((col("line_num") >= 1) & (F.trim(F.regexp_replace(col("line_text"), r"\r", "")) != ""))

    headers = aws_files.select(
        col("source_file").alias("h_file"),
        F.split(
            F.regexp_replace(F.trim(F.element_at(F.split(col("file_content"), "\n"), 1)), r'["\r]', ""),
            ",",
        ).alias("header_arr"),
    )

    with_header = (
        lines.join(headers, col("source_file") == col("h_file"))
        .withColumn("vals", F.split(F.regexp_replace(F.trim(col("line_text")), r'["\r]', ""), ","))
        .withColumn("total_col_idx", F.array_position(col("header_arr"), "Total costs($)").cast("int"))
        .withColumn(
            "reported_total",
            when(
                col("total_col_idx") > 0,
                F.element_at(col("vals"), col("total_col_idx")).cast("decimal(18,4)"),
            ).otherwise(lit(None)),
        )
        .withColumn("date_str", F.element_at(col("vals"), 1))
    )

    service_sums = (
        spark.read.table("_aws_parsed")
        .groupBy("source_file", "cost_date")
        .agg(F.sum("cost").cast("decimal(18,4)").alias("computed_total"))
    )

    reported = (
        with_header.filter(col("line_num") >= 2)
        .select(
            col("source_file").alias("r_file"),
            F.to_date(col("date_str"), "yyyy-MM-dd").alias("r_date"),
            col("reported_total"),
        )
        .filter(col("r_date").isNotNull())
    )

    comparison = (
        service_sums.join(
            reported,
            (col("source_file") == col("r_file")) & (col("cost_date") == col("r_date")),
            "left",
        )
        .withColumn(
            "pct_diff",
            when(
                (col("reported_total").isNotNull()) & (col("reported_total") != 0),
                F.abs(col("computed_total") - col("reported_total")) / col("reported_total") * 100,
            ).otherwise(lit(0)),
        )
        .withColumn("pass", col("pct_diff") <= lit(tolerance_pct))
    )

    return comparison.select(
        "source_file", "cost_date", "computed_total", "reported_total", "pct_diff", "pass"
    )


# =====================================================================
# Quarantine: files that fail validation
# =====================================================================
@dp.materialized_view(
    name="cloud_cost_quarantine",
    comment="Cloud cost files rejected for control-total mismatch or unregistered folder.",
)
def cloud_cost_quarantine():
    bronze = spark.read.table("bronze_cloud_cost_raw")
    config = spark.read.table(_config_table()).filter(col("active") == True)

    unregistered = bronze.join(
        config.select(col("provider").alias("cfg_prov"), col("source_folder").alias("cfg_folder")),
        (col("provider") == col("cfg_prov")) & (col("source_folder") == col("cfg_folder")),
        "left_anti",
    ).select(
        "source_file", "file_modification_time", "ingested_at",
        "provider", "source_folder",
        lit("UNREGISTERED_FOLDER").alias("reason"),
        lit(None).cast("string").alias("detail"),
    )

    ct = spark.read.table("_control_totals").filter(col("pass") == False)
    ct_files = ct.select("source_file").distinct()
    ct_detail = ct.groupBy("source_file").agg(
        F.concat_ws(
            "; ",
            F.collect_list(
                F.concat(
                    F.date_format("cost_date", "yyyy-MM-dd"),
                    lit(" diff="),
                    F.format_number("pct_diff", 2),
                    lit("%"),
                )
            ),
        ).alias("detail")
    )

    ct_quarantine = (
        bronze.join(ct_files, "source_file", "inner")
        .join(ct_detail, "source_file", "left")
        .select(
            "source_file", "file_modification_time", "ingested_at",
            "provider", "source_folder",
            lit("CONTROL_TOTAL_MISMATCH").alias("reason"),
            "detail",
        )
    )

    return unregistered.unionByName(ct_quarantine)


# =====================================================================
# Silver cloud cost: standard long format, deduplicated, scope-filtered
# =====================================================================
@dp.materialized_view(
    name="silver_cloud_cost",
    comment="Normalised cloud cost in standard long format. Latest file wins; service scope applied.",
    cluster_by=["cost_date", "provider"],
)
@dp.expect("valid_cost_date", "cost_date IS NOT NULL")
@dp.expect("non_negative_cost", "cost >= 0 OR allocation_basis = 'CREDIT'")
def silver_cloud_cost():
    aws = spark.read.table("_aws_parsed")
    generic = spark.read.table("_generic_parsed")
    combined = aws.unionByName(generic, allowMissingColumns=True)

    quarantine_files = spark.read.table("cloud_cost_quarantine").select("source_file").distinct()
    combined = combined.join(quarantine_files, "source_file", "left_anti")

    # Latest file wins per (provider, folder, date, granularity, service)
    w_dedup = Window.partitionBy(
        "provider", "source_folder", "cost_date", "granularity", "service_name"
    ).orderBy(col("file_modification_time").desc())
    combined = combined.withColumn("_rn", F.row_number().over(w_dedup)).filter(col("_rn") == 1).drop("_rn")

    # No mixed granularity: if a month has DAILY rows, drop MONTHLY rows for that month
    combined = combined.withColumn("_month", F.date_trunc("month", "cost_date"))
    daily_months = (
        combined.filter(col("granularity") == "DAILY")
        .select(
            col("provider").alias("dm_prov"),
            col("source_folder").alias("dm_folder"),
            col("_month").alias("dm_month"),
        )
        .distinct()
    )
    combined = combined.join(
        daily_months,
        (col("provider") == col("dm_prov"))
        & (col("source_folder") == col("dm_folder"))
        & (col("_month") == col("dm_month"))
        & (col("granularity") == "MONTHLY"),
        "left_anti",
    ).drop("_month")

    # Service scope filter from config
    scope = spark.read.table(_config_table()).filter(col("active") == True).select(
        col("provider").alias("sc_prov"),
        col("source_folder").alias("sc_folder"),
        col("services_in_scope").alias("sc_scope"),
    )
    combined = combined.join(
        scope,
        (col("provider") == col("sc_prov")) & (col("source_folder") == col("sc_folder")),
        "left",
    ).filter(
        (col("sc_scope").isNull())
        | (F.upper(F.trim(col("sc_scope"))) == "ALL")
        | F.array_contains(
            F.transform(F.split(col("sc_scope"), ","), lambda s: F.trim(s)),
            F.trim(col("service_name")),
        )
    )

    return combined.select(
        "provider", "source_folder", "environment", "cost_date", "granularity",
        "service_name", "cost", "currency", "allocation_basis",
        "source_file", "file_modification_time", "ingested_at", "adapter",
    )
