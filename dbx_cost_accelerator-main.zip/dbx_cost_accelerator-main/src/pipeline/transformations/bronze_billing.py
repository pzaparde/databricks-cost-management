"""Bronze layer: Databricks billing usage from system tables.

REPLACE WHERE keeps long-term history while re-reading a lookback window on every run to
capture late or restated billing records.

Self-bootstrapping: when the target table does not exist yet (first deployment) or when
`force_full_reload` = true, the replace window widens to `history_start_date`, so a fresh
install loads full history with no manual backfill step.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

_catalog = spark.conf.get("catalog")
_schema = spark.conf.get("schema")
_lookback_days = int(spark.conf.get("lookback_days"))
_history_start = spark.conf.get("history_start_date", "").strip() or "2025-01-01"
_force_full = spark.conf.get("force_full_reload", "false").strip().lower() == "true"

_first_run = (
    spark.sql(
        f"SELECT 1 FROM `{_catalog}`.information_schema.tables "
        f"WHERE table_schema = '{_schema}' AND table_name = 'bronze_billing_usage'"
    ).isEmpty()
)

if _first_run or _force_full:
    _replace_where = f"usage_date >= '{_history_start}'"
else:
    _replace_where = f"usage_date >= date_add(current_date(), -{_lookback_days})"


@dp.table(
    name="bronze_billing_usage",
    comment="Long-term copy of system.billing.usage. Lookback window refreshed each run to capture restatements.",
    table_properties={"pipelines.reset.allowed": "false"},
    cluster_by=["usage_date", "workspace_id"],
    replace_where=_replace_where,
)
def bronze_billing_usage():
    ws_filter = spark.conf.get("workspace_filter")

    df = spark.read.table("system.billing.usage").filter(
        F.col("usage_date") >= F.lit(_history_start)
    )

    if ws_filter.strip().upper() != "ALL":
        ws_ids = [w.strip() for w in ws_filter.split(",") if w.strip()]
        df = df.filter(F.col("workspace_id").isin(ws_ids))

    return df
