"""Silver layer: Enriched Databricks billing usage.
Pricing (account with list fallback), environment mapping, tag attributes, workload derivation.
Money stored as DECIMAL(38,10).
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.functions import col, coalesce, lit, when
from pyspark.sql.window import Window

_TAG_ATTRIBUTES = ["product", "sub_product", "cost_center", "team", "owner", "project"]


@dp.materialized_view(
    name="silver_billing_usage",
    comment="Enriched billing usage: priced, environment-mapped, tag-attributed.",
    cluster_by=["usage_date", "workspace_id"],
)
@dp.expect("valid_record_id", "record_id IS NOT NULL")
@dp.expect("valid_usage_date", "usage_date IS NOT NULL")
@dp.expect("non_negative_quantity", "usage_quantity >= 0")
@dp.expect("has_unit_price", "unit_price IS NOT NULL")
def silver_billing_usage():
    cfg_catalog = spark.conf.get("catalog")
    cfg_schema = spark.conf.get("schema")
    pricing_mode = spark.conf.get("pricing_mode", "account_with_list_fallback").strip().lower()
    list_discount = float(spark.conf.get("list_price_discount_pct"))
    addl_discount = float(spark.conf.get("additional_discount_pct"))

    bronze = spark.read.table("bronze_billing_usage")

    # -- Pricing tables -----------------------------------------------------
    #   account_prices is optional: if the table is unavailable (not enabled or
    #   no access), every record falls through to list prices automatically.
    from pyspark.sql.types import StructType, StructField, StringType, TimestampType, DecimalType
    _ap_schema = StructType([
        StructField("ap_sku", StringType()),
        StructField("ap_unit", StringType()),
        StructField("ap_start", TimestampType()),
        StructField("ap_end", TimestampType()),
        StructField("account_unit_price", DecimalType(38, 10)),
    ])
    if pricing_mode == "list":
        # list-only mode: ignore negotiated prices
        account_prices = spark.createDataFrame([], _ap_schema)
    else:
        try:
            account_prices = spark.read.table("system.billing.account_prices").select(
                col("sku_name").alias("ap_sku"),
                col("usage_unit").alias("ap_unit"),
                col("price_start_time").alias("ap_start"),
                coalesce(col("price_end_time"), lit("9999-12-31").cast("timestamp")).alias("ap_end"),
                col("pricing.default").alias("account_unit_price"),
            )
        except Exception:
            account_prices = spark.createDataFrame([], _ap_schema)

    list_prices = spark.read.table("system.billing.list_prices").select(
        col("sku_name").alias("lp_sku"),
        col("usage_unit").alias("lp_unit"),
        col("price_start_time").alias("lp_start"),
        coalesce(col("price_end_time"), lit("9999-12-31").cast("timestamp")).alias("lp_end"),
        col("pricing.effective_list.default").alias("list_unit_price"),
    )

    # -- Config tables (created by setup task, not pipeline-owned) ----------
    ws_env = (
        spark.read.table(f"{cfg_catalog}.{cfg_schema}.config_workspace_env")
        .filter(col("include_flag") == True)
        .select(
            col("workspace_id").alias("we_ws_id"),
            col("environment"),
            col("workspace_name"),
            col("business_unit"),
        )
    )

    tag_mapping = spark.read.table(f"{cfg_catalog}.{cfg_schema}.config_tag_mapping")

    # -- Account price join (valid at usage_end_time) -----------------------
    df = bronze.join(
        account_prices,
        (col("sku_name") == col("ap_sku"))
        & (col("usage_unit") == col("ap_unit"))
        & (col("usage_end_time") >= col("ap_start"))
        & (col("usage_end_time") < col("ap_end")),
        "left",
    )

    # -- List price join (fallback) -----------------------------------------
    df = df.join(
        list_prices,
        (col("sku_name") == col("lp_sku"))
        & (col("usage_unit") == col("lp_unit"))
        & (col("usage_end_time") >= col("lp_start"))
        & (col("usage_end_time") < col("lp_end")),
        "left",
    )

    list_factor = 1.0 - list_discount / 100.0
    addl_factor = 1.0 - addl_discount / 100.0

    df = (
        df.withColumn(
            "unit_price",
            (
                when(col("account_unit_price").isNotNull(), col("account_unit_price"))
                .otherwise(col("list_unit_price") * lit(list_factor))
                * lit(addl_factor)
            ).cast("decimal(38,10)"),
        )
        .withColumn(
            "price_source",
            when(col("account_unit_price").isNotNull(), lit("ACCOUNT"))
            .when(col("list_unit_price").isNotNull(), lit("LIST"))
            .otherwise(lit("UNPRICED")),
        )
        .withColumn(
            "usage_cost",
            (col("usage_quantity") * col("unit_price")).cast("decimal(38,10)"),
        )
    )

    # -- Environment mapping ------------------------------------------------
    df = df.join(ws_env, col("workspace_id") == col("we_ws_id"), "left").withColumn(
        "environment", coalesce(col("environment"), lit("UNASSIGNED"))
    )

    # -- Tag attribute extraction -------------------------------------------
    #   explode custom_tags -> join config_tag_mapping -> best priority -> pivot
    tags_exploded = bronze.select(
        col("record_id").alias("t_rid"),
        F.explode_outer("custom_tags").alias("tag_key", "tag_value"),
    )

    tags_mapped = tags_exploded.join(
        tag_mapping,
        tags_exploded["tag_key"] == tag_mapping["source_tag_key"],
        "inner",
    )

    w_tag = Window.partitionBy("t_rid", "standard_attribute").orderBy("priority")
    tags_best = (
        tags_mapped.withColumn("rn", F.row_number().over(w_tag))
        .filter(col("rn") == 1)
        .select("t_rid", "standard_attribute", "tag_value")
    )

    tags_pivoted = (
        tags_best.groupBy("t_rid")
        .pivot("standard_attribute", _TAG_ATTRIBUTES)
        .agg(F.first("tag_value"))
    )

    df = df.join(tags_pivoted, col("record_id") == col("t_rid"), "left")
    for attr in _TAG_ATTRIBUTES:
        df = df.withColumnRenamed(attr, f"tag_{attr}")

    # -- Workload name derivation -------------------------------------------
    df = df.withColumn(
        "workload_name",
        when(col("billing_origin_product") == "JOBS", col("usage_metadata.job_name"))
        .when(
            col("billing_origin_product") == "INTERACTIVE",
            F.element_at(F.split(col("usage_metadata.notebook_path"), "/"), -1),
        )
        .when(col("billing_origin_product") == "ALL_PURPOSE", col("usage_metadata.node_type"))
        .when(
            col("billing_origin_product") == "SQL",
            coalesce(
                F.concat(lit("warehouse: "), col("usage_metadata.warehouse_id")),
                F.concat(lit("endpoint: "), col("usage_metadata.endpoint_name")),
            ),
        )
        .when(
            col("billing_origin_product") == "DLT",
            F.concat(lit("pipeline: "), col("usage_metadata.dlt_pipeline_id")),
        )
        .when(
            col("billing_origin_product") == "MODEL_SERVING",
            coalesce(col("usage_metadata.endpoint_name"), lit("model_serving")),
        )
        .when(
            col("billing_origin_product") == "LAKEFLOW_CONNECT",
            col("usage_metadata.dlt_pipeline_id"),
        )
        .otherwise(col("billing_origin_product")),
    )

    # -- Photon / serverless flags ------------------------------------------
    df = df.withColumn(
        "photon_status",
        when(col("product_features.is_photon") == True, lit("Photon")).otherwise(lit("Spark")),
    ).withColumn(
        "serverless_classic",
        when(col("product_features.is_serverless") == True, lit("Serverless")).otherwise(lit("Classic")),
    )

    return df.select(
        "account_id",
        "workspace_id",
        "workspace_name",
        "record_id",
        "sku_name",
        "cloud",
        "usage_start_time",
        "usage_end_time",
        "usage_date",
        "custom_tags",
        "usage_unit",
        "usage_quantity",
        "usage_metadata",
        "identity_metadata",
        "record_type",
        "ingestion_date",
        "billing_origin_product",
        "product_features",
        "usage_type",
        "unit_price",
        "price_source",
        "usage_cost",
        "environment",
        "business_unit",
        "tag_product",
        "tag_sub_product",
        "tag_cost_center",
        "tag_team",
        "tag_owner",
        "tag_project",
        "workload_name",
        "photon_status",
        "serverless_classic",
    )
