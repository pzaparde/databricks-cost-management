"""Gold layer: Aggregated cost tables.
All money columns stored as DECIMAL(18,4).
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, sum as _sum, date_trunc

_DIMENSIONS = [
    "workspace_id",
    "workspace_name",
    "environment",
    "business_unit",
    "sku_name",
    "billing_origin_product",
    "usage_type",
    "usage_unit",
    "workload_name",
    "tag_product",
    "tag_sub_product",
    "tag_cost_center",
    "photon_status",
    "serverless_classic",
    "price_source",
    "unit_price",
]


# =====================================================================
# Databricks cost - daily grain
# =====================================================================
@dp.materialized_view(
    name="gold_dbx_cost_daily",
    comment="Databricks cost aggregated to date x workspace x sku x billing product.",
    cluster_by=["usage_date", "environment"],
)
@dp.expect_or_fail("has_usage_date", "usage_date IS NOT NULL")
def gold_dbx_cost_daily():
    silver = spark.read.table("silver_billing_usage")
    return silver.groupBy("usage_date", *_DIMENSIONS).agg(
        _sum("usage_quantity").cast("decimal(18,4)").alias("usage_quantity"),
        _sum("usage_cost").cast("decimal(18,4)").alias("usage_cost"),
        F.count("*").alias("record_count"),
    )


# =====================================================================
# Databricks cost - monthly grain
# =====================================================================
@dp.materialized_view(
    name="gold_dbx_cost_monthly",
    comment="Databricks cost aggregated to month x workspace x sku x billing product.",
    cluster_by=["usage_month", "environment"],
)
@dp.expect_or_fail("has_usage_month", "usage_month IS NOT NULL")
def gold_dbx_cost_monthly():
    daily = spark.read.table("gold_dbx_cost_daily")
    return (
        daily.withColumn("usage_month", date_trunc("month", "usage_date").cast("date"))
        .groupBy("usage_month", *_DIMENSIONS)
        .agg(
            _sum("usage_quantity").cast("decimal(18,4)").alias("usage_quantity"),
            _sum("usage_cost").cast("decimal(18,4)").alias("usage_cost"),
            _sum("record_count").alias("record_count"),
        )
    )


# =====================================================================
# Cloud cost - monthly grain
# =====================================================================
@dp.materialized_view(
    name="gold_cloud_cost_monthly",
    comment="Cloud cost aggregated to month x provider x environment x service.",
    cluster_by=["cost_month", "provider"],
)
def gold_cloud_cost_monthly():
    silver = spark.read.table("silver_cloud_cost")
    return (
        silver.withColumn("cost_month", date_trunc("month", "cost_date").cast("date"))
        .groupBy(
            "cost_month",
            "provider",
            "environment",
            "service_name",
            "currency",
            "allocation_basis",
        )
        .agg(
            _sum("cost").cast("decimal(18,4)").alias("total_cost"),
            F.count("*").alias("row_count"),
            F.countDistinct("source_file").alias("file_count"),
        )
    )


# =====================================================================
# Total cost - Databricks + cloud, monthly
# =====================================================================
@dp.materialized_view(
    name="gold_total_cost_monthly",
    comment="Combined Databricks and cloud cost by month and environment.",
    cluster_by=["cost_month", "environment"],
)
def gold_total_cost_monthly():
    currency = spark.conf.get("currency")

    dbx = (
        spark.read.table("gold_dbx_cost_monthly")
        .groupBy("usage_month", "environment")
        .agg(_sum("usage_cost").cast("decimal(18,4)").alias("total_cost"))
        .withColumn("cost_source", lit("DATABRICKS"))
        .withColumnRenamed("usage_month", "cost_month")
        .withColumn("currency", lit(currency))
    )

    cloud = (
        spark.read.table("gold_cloud_cost_monthly")
        .groupBy("cost_month", "environment", "currency")
        .agg(_sum("total_cost").cast("decimal(18,4)").alias("total_cost"))
        .withColumn("cost_source", lit("CLOUD"))
    )

    cols = ["cost_month", "environment", "cost_source", "total_cost", "currency"]
    return dbx.select(*cols).unionByName(cloud.select(*cols))
